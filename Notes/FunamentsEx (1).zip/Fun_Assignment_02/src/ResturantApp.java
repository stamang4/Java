import java.util.Scanner;

public class ResturantApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		while(true)
		{
System.out.println("*****************************************");
System.out.println("       1) Biryani              "   );
System.out.println("       2)Exit                            ");

System.out.println("*****************************************");

System.out.println("Enter The choice");
int choice=sc.nextInt();
switch(choice)
{
case 1:
	ChickenBiryaniDetails details=new ChickenBiryaniDetails();
	details.briyaniDetails();
	break;
case 2:
	System.out.println("Thx for Using App!");
	System.exit(0);
	default:
		System.out.println("choose 1 to 2 between");
	
}

		}
	}

}
