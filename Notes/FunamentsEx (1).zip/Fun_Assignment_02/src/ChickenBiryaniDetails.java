import java.util.Scanner;

public class ChickenBiryaniDetails {

	void chickenBiryani()
	{
		
		System.out.println("Thx for eating Me");
	}//end of this Method
	Scanner sc=new Scanner(System.in);
	public void briyaniDetails()
	{
		
		System.out.println("*****************************************");
		System.out.println("       1) chicken Biryani              "   );
		System.out.println("       2)Back                            ");

		System.out.println("*****************************************");
		System.out.println("Enter the Choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			chickenBiryani();
			briyaniDetails();
			break;
		case 2:
			ResturantApp.main(null);
			default:
				System.out.println("Choose 1 to 2 between");
		}
		
		
	}
}
