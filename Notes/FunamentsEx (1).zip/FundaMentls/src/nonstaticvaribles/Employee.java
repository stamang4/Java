package nonstaticvaribles;

public class Employee {

	int eno=100;
	String ename;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee emp=new Employee();

Employee emp1=new Employee();

emp.ename="rani";

System.out.println(emp.eno+"\t"+emp.ename);

System.out.println(emp1.eno+"\t"+emp1.ename);


System.out.println(emp);//address(classname@hashCode)

System.out.println(emp1);//address(classname@hashCode)
	}

}
