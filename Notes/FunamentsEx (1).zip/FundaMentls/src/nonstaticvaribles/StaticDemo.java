package nonstaticvaribles;

public class StaticDemo {

	//static varibles/class varibles
	static int i=100;
	
	//static Method
	static void funA()
	{
		System.out.println("Static Methods");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Directly : "+i);
funA();

System.out.println("Using ClassName : "+StaticDemo.i);
StaticDemo.funA();

StaticDemo demo=new StaticDemo();
System.out.println("Using Object : "+demo.i);
demo.funA();

StaticDemo demo1=null;

System.out.println("Using Object : "+demo1.i);
demo1.funA();



	}

}
