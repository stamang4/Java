package nonstaticvaribles;

public class Account {

	int accNo=1000;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Account acc=null;
System.out.println(acc.accNo);
	}

}
