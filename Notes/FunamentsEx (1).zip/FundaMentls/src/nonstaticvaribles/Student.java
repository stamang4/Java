package nonstaticvaribles;

public class Student {
	// non-static varibles/Instance varibles
	int sno;
	String sname;
	double sfee;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stu = new Student();
		System.out.println(stu.sno + "\t" + stu.sname + "\t" + stu.sfee);

		stu.sno = 100;
		stu.sname = "rani";
		stu.sfee = 2500;
		System.out.println(stu.sno + "\t" + stu.sname + "\t" + stu.sfee);

	}

}
