package localvaribles;

public class Welcome {

	//java is a case sensitive
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Welcome To Takeo Boot Camp");
	}

}
