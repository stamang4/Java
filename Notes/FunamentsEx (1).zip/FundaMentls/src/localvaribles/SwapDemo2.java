package localvaribles;
/**
 * 
 * 
 * @author Admin
 *   Swaping of two number with temp variable
 */


public class SwapDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fno = 100;
		int sno = 200;
int tno=300;
		System.out.println("Before Swapping : ");
		System.out.println("Fno : " + fno + "  Sno : " + sno+"\t"+" tno : "+tno);
//swapping
		int temp=0;
		temp=fno;
		fno=sno;
		sno=tno;
		tno=temp;
		
		System.out.println("After Swapping : ");
		System.out.println("Fno : " + fno + "  Sno : " + sno+"\t"+" tno : "+tno);	
		
		
		
		
	}

}
