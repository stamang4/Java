package localvaribles;

public class SwapDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fno = 100;
		int sno = 200;
int tno=300;
		System.out.println("Before Swapping : ");
		System.out.println("Fno : " + fno + "  Sno : " + sno+"\t"+" tno : "+tno);
		
	//swapping
		
		fno=fno+sno+tno;//100+200+300=600
		sno=fno-sno-tno;//600-200-300=100
		tno=fno-sno-tno;//600-100-300=200
		fno=fno-sno-tno;//600-100-200=300
		
		System.out.println("After Swapping : ");
		System.out.println("Fno : " + fno + "  Sno : " + sno+"\t"+" tno : "+tno);	
		
		
		
	}

}
