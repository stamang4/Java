package localvaribles;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// localVaribles
		int sno = 100;
		String sname = "shiva";
		double sfee = 250.25;

		boolean flag = true;

		System.out.println(sno + "\t" + sname + "\t" + sfee + "\t" + flag);

	}

}
