package Operators;

public class Test {
	//jvm will assign default values
	int x,y=900;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//jvm will not assign default value for local varibles
int a=20,b=15,c=30;
System.out.println(a+"\t"+b+"\t"+c);
System.out.println(new Test().x=900);
System.out.println(new Test().y);
System.out.println(new Test().x=900);

	}

}
