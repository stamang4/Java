package Operators;

public class OperatorEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=10;
int y=++x;//pre increment
System.out.println(x);//11
System.out.println(y);//11


int a=10;
int b=a++;//post increment
System.out.println(a);//11
System.out.println(b);//10
System.out.println(a--);//post decrement 11
System.out.println(a);//10




	}

}
