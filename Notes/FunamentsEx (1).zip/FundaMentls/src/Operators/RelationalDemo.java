package Operators;

public class RelationalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(10>2);
System.out.println(10<2);

System.out.println(10>=2);

System.out.println(10<=2);

System.out.println(10==100);
System.out.println(10!=20);




	
	
	}

}
