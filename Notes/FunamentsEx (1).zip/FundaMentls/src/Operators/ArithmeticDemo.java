package Operators;

public class ArithmeticDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(10+10);
System.out.println(200-100);

System.out.println(10*10);
System.out.println(10/2);
System.out.println(10%2);





	}

}
