package Operators;

public class LeftShiftEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//left shift operator
System.out.println(10<<2);//10*2^2=10*4=40
System.out.println(10<<3);//10*2^3=10*8=80
System.out.println(20<<2);//20*2^3=20*4=80

System.out.println(15<<3);//15*2^3=15*8=120







	}

}
