package flowcontrols;

public class Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			// TODO Auto-generated method stub
			int k=2;
			for(int i=0;i<10;i++)
			{
				for(int j=0;j<5;j++)
				{
					System.out.print(k+" ");
					k+=2;
				}
				System.out.println();
				
			}
				}

			

		

	}
