package flowcontrols;

public class SwitchCaseDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b=50;
	final	byte c=20;
switch(b+20)
{
case c+30:
System.out.println("10 execute");
break;
case 20:
System.out.println("20 execute");
break;
case 30:
System.out.println("30 execute");
break;

default:
	System.out.println("its ok we will check later");



}
	}

}
