package flowcontrols;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10;
if(x==10)//false
{
	int z=90;
}
else
	System.out.println("Macha");
	
	
	
	
	
	}

}
