package flowcontrols;

import java.util.Scanner;

public class NestedIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Age");
		int num = sc.nextInt();
		if (num > 18) {

			System.out.println("Enter The weight");
			int weight = sc.nextInt();
			if (weight > 40)
				System.out.println("He/She Can give the Blood");
			else
				System.out.println("Under Weight Can't provide the blood");

		} // end of if
		else {
			System.out.println("He/She is Minor");
		}
	}

}
