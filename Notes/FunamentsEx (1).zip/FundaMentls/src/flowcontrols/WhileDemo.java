package flowcontrols;

public class WhileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * int i=0; while(i<5) { System.out.println(i); i++; }
		 */

		/*
		 * int i=0; while(i<5);//once condtion fails { System.out.println(i); i++; }
		 */



		int i=0;
		boolean flag=true;
		while(flag)//once condtion fails
		{
			if(i==5)
			{
			System.out.println(i);
			flag=false;
			}
			i++;
		}

		
		
	}

}
