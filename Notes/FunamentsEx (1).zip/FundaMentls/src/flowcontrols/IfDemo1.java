package flowcontrols;

import java.util.Scanner;

public class IfDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Age");
		int num=sc.nextInt();
		if(num%2==0)
			System.out.println("Even Number");
		else
			System.out.println("Not A Even Number");
	}

}
