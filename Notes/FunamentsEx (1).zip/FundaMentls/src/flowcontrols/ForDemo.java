package flowcontrols;

import java.util.Scanner;

public class ForDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Number");
		int num = sc.nextInt();//10
		/*
		 * for (int i = 1; i <= num; ++i) { System.out.println(i);//1
		 * 
		 * } // end of for
		 */
//		int i = 1;
//		for (System.out.println("Hi"); i <= num; System.out.println("Bye")) {
//			System.out.println(i);
//++i;
//		} // end of for
	
	
		int i ;
		for (i=1,System.out.println("Hi"); i <= num; System.out.println("Bye"),++i) {
			System.out.println(i);

		} // end of for
	}

	
	
	
}
