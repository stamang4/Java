package flowcontrols;

public class PatternEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=0;i<5;i++)//0<5 1<5
{
	for(int j=0;j<5;j++)//0<5 1<5 2<5 3<5 4<5 5<5
	{
		System.out.print("*"+" ");//* * * * *
	}
	System.out.println();
}
	}

}
